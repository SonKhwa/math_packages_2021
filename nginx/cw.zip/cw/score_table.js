window.onload = () => {
    let data = JSON.parse(localStorage.getItem("score_table"));
    if (data === null)
        return;
    for (let i = 0; i < data.length; i++) {
        let div = document.createElement('div');
        div.innerHTML = '<p>' + data[i].username + ': ' + data[i].score + '</p>';
        document.getElementById("score_table").appendChild(div);
    }
}

function updateScore() {
    let score = document.getElementById("score");
    score.innerHTML = '<p>Score: ' + Player.score + '</p>';
}
function saveToStorage() {
let input = document.getElementById("username");
    let data;
    if (localStorage.getItem("score_table"))
        data = JSON.parse(localStorage.getItem("score_table"));
    else
        data = [];
    data.push({username: input.value, score: Player.score});
    data.sort(function(a, b) {
        return b.score - a.score;
    });
localStorage.setItem('score_table', JSON.stringify(data));
    closeModal();
}

function closeModal() {
    const modal = document.getElementById('myModal');
    modal.style.display = "none";
}

function openModal() {
    const modal = document.getElementById('myModal');
    modal.style.display = "block";
}
