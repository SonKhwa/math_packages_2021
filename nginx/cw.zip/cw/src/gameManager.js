const gameManager = {
    factory: {},
    entities: [],
    enemies: [],
    player: null,
    laterKill: [],
    currentLevelNum: 1,
    intervaFunc: null,
    initGame: function () {
        this.entities = []
        this.enemies = []
        this.laterKill = []
        this.intervaFunc = null
    },
    initPlayer: function (obj) {
        this.player = obj;
    },
    kill: function (obj) {
        this.laterKill.push(obj);
    },
    update: function (ctx) {
        if (!this.player) {
            return;
        }
        this.player.move_x = 0;
        this.player.move_y = 0;
        if (eventsManager.action["up"]) {
            this.player.move_y = -1;
            this.player.status = "up";
        }
        if (eventsManager.action["down"]) {
            this.player.move_y = 1;
            this.player.status = "down";
        }
        if (eventsManager.action["left"]) {
            this.player.move_x = -1;
            this.player.status = "left";
        }
        if (eventsManager.action["right"]) {
            this.player.move_x = 1;
            this.player.status = "right";
        }
        if (eventsManager.action["fire"]) {
            this.player.fire();
        }
        for (let enemy of this.enemies) {
            enemy.move_x = (enemy.pos_x - this.player.pos_x) < 0 ? 1 : -1;
            enemy.move_y = (enemy.pos_y - this.player.pos_y) < 0 ? 1 : -1;
        }
        this.entities.forEach(function (e) {
            try {
                e.update();
            } catch (ex) {}
        });
        for (let i = 0; i < this.laterKill.length; i++) {
            const idx = this.entities.indexOf(this.laterKill[i]);
            if (idx > -1) this.entities.splice(idx, 1);
        }
        if (this.laterKill.length > 0)
            this.laterKill.length = 0;
        mapManager.draw(ctx);
        mapManager.centerAt(this.player.pos_x, this.player.pos_y);
        this.draw(ctx);
    },
    draw: function () {
        for (let e = 0; e < this.entities.length; e++)
            this.entities[e].draw(ctx);
    },
    loadAll: function (ctx, mapName, atlasName) {
        mapManager.loadMap(mapName);
        spriteManager.loadSprites(atlasName);
        this.factory[Entities.PLAYER.name] = Player;
        this.factory[Entities.ENEMY.name] = Enemy;
        this.factory[Entities.ROCKET.name] = Rocket;
        this.factory[Entities.COIN.name] = Coin;
        this.factory[Entities.EXIT.name] = Exit;
        this.factory[Entities.WALL.name] = Wall;
        mapManager.parseEntities();
        mapManager.draw(ctx);
        eventsManager.setup(ctx.canvas);
    },
    startGame: function (ctx) {
        soundManager.play("sound/music.mp3", { looping: true, volume: 0.2 });
        this.loadAll(ctx, "tiles/game_map.json", "tiles/characters_tiles.json");
        Player.score = 0;
        this.play(ctx);
    },
    play: function (ctx) {
        this.intervaFunc = setInterval(() => {updateWorld(ctx); }, 100);
    },
    initAll: function () {
      mapManager.initMap();
      spriteManager.initSprite();
      gameManager.initGame();
    },
    loadNextLevel: function () {
        clearInterval(this.intervaFunc);
        if (this.currentLevelNum === 2) {
            endGame();
            return;
        }
        gameManager.initAll();
        this.currentLevelNum = 2;
        this.loadAll(ctx, "tiles/game_map2.json", "tiles/characters_tiles.json");
        this.play(ctx);
    }
};

function updateWorld(ctx) {
    gameManager.update(ctx);
    updateScore();
}

function endGame() {
    soundManager.toggleMute();
    openModal();
}

function restartGame() {
    Player.score = 0;
    window.location.reload();
}
