const maxFrameNum = 3;
const Entity = {
    pos_x: 0, pos_y: 0,
    size_x: 0, size_y: 0,
    extend: function (extendProto) {
        const object = Object.create(this);
        for (let property in extendProto) {
            if (this.hasOwnProperty(property) || typeof object[property] === "undefined") {
                object[property] = extendProto[property];
            }
        }
        return object;
    },
};
const Player = Entity.extend({
    score: 0,
    move_x: 0, move_y: 0,
    speed: 5,
    animIndex: 0,
    status: "down",
    draw: function (ctx) {
        spriteManager.drawSprite(ctx, Entities.PLAYER.name, this.pos_x, this.pos_y, this.animIndex, this.status
        );
        this.animIndex++;
        if (this.animIndex === maxFrameNum) {
            this.animIndex = 0;
        }
    },
    update: function () {
        physicManager.update(this);
    },
    onTouchEntity: function (obj) {
        if (obj.name === Entities.COIN.name) {
            soundManager.playWorldSound("sound/coin.mp3", this.pos_x, this.pos_y);
            Player.score += 50;
            obj.kill();
        }
        if (obj.name === Entities.ENEMY.name) {
            obj.kill();
            this.kill();
        }
        if (obj.name === Entities.EXIT.name) {
            soundManager.playWorldSound("sound/nextLvl.mp3", this.pos_x, this.pos_y);
            gameManager.loadNextLevel();
        }
    },
    kill: function () {
        soundManager.playWorldSound("sound/died.mp3", this.pos_x, this.pos_y);
        gameManager.laterKill.push(this);
        endGame();
    },
    fire: function () {
        const r = Object.create(Rocket);
        r.size_x = 16;
        r.size_y = 16;
        r.name = Entities.ROCKET.name;
        r.move_x = this.move_x;
        r.move_y = this.move_y;
        switch (this.move_x + 2 * this.move_y) {
            case -1: {
                r.pos_x = this.pos_x - r.size_x;
                r.pos_y = this.pos_y;
                r.status = "left";
                break;
            }
            case 1: {
                r.pos_x = this.pos_x + this.size_x;
                r.pos_y = this.pos_y;
                r.status = "right";
                break;
            }
            case -2: {
                r.pos_x = this.pos_x;
                r.pos_y = this.pos_y - r.size_y;
                r.status = "up";
                break;
            }
            case 2: {
                r.pos_x = this.pos_x;
                r.pos_y = this.pos_y + this.size_y;
                r.status = "down";
                break;
            }
        }
        if (r.pos_x === 0 && r.pos_y === 0)
            return;
        soundManager.playWorldSound("sound/shot.mp3", r.pos_x, r.pos_y);
        gameManager.entities.push(r);
    }
});

const Coin = Entity.extend({
    draw: function (ctx) {
        spriteManager.drawSprite(ctx, Entities.COIN.name, this.pos_x, this.pos_y);
    },
   kill: function () {
        gameManager.laterKill.push(this);
    }
});

const Exit = Entity.extend({
    draw: function (ctx) {
        spriteManager.drawSprite(ctx, Entities.EXIT.name, this.pos_x, this.pos_y);
    }
});

const Wall = Entity.extend({
    draw: function (ctx) {
        spriteManager.drawSprite(ctx, Entities.WALL.name, this.pos_x, this.pos_y);
    }
});


const Enemy = Entity.extend({
    lifetime: 100,
    move_x: 0, move_y: -1,
    speed: 2,
    animIndex: 0,
    status: "down",
    draw: function (ctx) {
        spriteManager.drawSprite(ctx, Entities.ENEMY.name, this.pos_x, this.pos_y, this.animIndex, this.status
        );
        this.animIndex++;
        if (this.animIndex === maxFrameNum) {
            this.animIndex = 0;
        }
    },
    update: function () {
        physicManager.update(this);
    },
    onTouchEntity: function (obj) {
        if (obj.name === Entities.PLAYER.name) {
            obj.kill();
            this.kill();
        }
    },
    kill: function () {
        gameManager.laterKill.push(this);
    }
});

const Rocket = Entity.extend({
    move_x: 0, move_y: 0,
    speed: 4,
    animIndex: 0,
    status: "down",
    draw: function (ctx) {
        spriteManager.drawSprite(ctx, Entities.ROCKET.name, this.pos_x, this.pos_y, this.animIndex, this.status
        );
        this.animIndex++;
        if (this.animIndex === maxFrameNum) {
            this.animIndex = 0;
        }
    },
    update: function () {
        physicManager.update(this);
    },
    onTouchEntity: function (obj) {
        if (obj.name === Entities.ENEMY.name) {
            soundManager.playWorldSound("sound/coin.mp3", obj.pos_x, obj.pos_y);
             Player.score += 50;
            obj.kill();
        }
        this.kill();
    },
    kill: function () {
        gameManager.laterKill.push(this);
    }
});
