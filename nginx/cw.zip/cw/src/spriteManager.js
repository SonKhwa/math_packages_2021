const Entities = {
    PLAYER: {name: "player", down: 6,left: 18, right: 30, up: 42, dead: 98},
    ENEMY: {name: "enemy", down: 57,left: 69, right: 81, up: 93, dead: 112},
    ROCKET: {name: "rocket", down: 51,left: 63, right: 75, up: 87, dead: 101},
    COIN: {name: "coin", id: 113},
    EXIT: {name: "exit", id: 102},
    WALL: {name: "wall", id: 114}
};

const spriteManager = {
     image: new Image(),
     spriteData: null,
    xCount: 0,
    yCount: 0,
     animations: [],
     imgLoaded: false,
     jsonLoaded: false,
    initSprite: function () {
        this.image = new Image()
        this.animations = []
        this.imgLoaded = false
        this.jsonLoaded = false
    },
     loadSprites: function (path) {
         const request = new XMLHttpRequest();
         request.onreadystatechange = function () {
             if (request.readyState === 4 && request.status === 200) {
                 spriteManager.parseAtlas(request.responseText);
             }
         };
         request.open("GET", path, true);
         request.send();
     },
     loadImg: function (imgName) {
         this.image.onload = function () {
             spriteManager.imgLoaded = true;
         };
         this.image.src = imgName;
     },
     parseAtlas: function (atlasJSON) {
         this.spriteData = JSON.parse(atlasJSON);
         this.xCount = this.spriteData.imagewidth / this.spriteData.tilewidth;
         this.yCount = this.spriteData.imageheight / this.spriteData.tileheight;
        for (let tile of this.spriteData.tiles) {
            this.animations.push(tile);
        }
        this.jsonLoaded = true;
        this.loadImg(`/tiles/${this.spriteData.image}`);
    },
    drawSprite: function (ctx, name, x, y, animIndex = 0, status = "down") {
        if (!this.imgLoaded || !this.jsonLoaded) {
            setTimeout(() => {
                spriteManager.drawSprite(ctx, name, x, y, animIndex, status);
            }, 100);
        } else {
            let spriteId = this.getSprite(name, animIndex, status);
            if (!mapManager.isVisible(x, y, this.spriteData.tilewidth, this.spriteData.tileheight))
                return;
            x -= mapManager.view.x;
            y -= mapManager.view.y;
            let x_ = spriteId % this.xCount;
            let y_ = Math.floor(spriteId / this.xCount);
            x_ *= this.spriteData.tilewidth;
            y_ *= this.spriteData.tileheight;
            ctx.drawImage(this.image, x_, y_, this.spriteData.tilewidth, this.spriteData.tileheight, x, y, this.spriteData.tilewidth, this.spriteData.tileheight);
        }
    },
    getSprite: function (name, animIndex, status) {
         let id = -1;
         switch (name) {
             case Entities.PLAYER.name:

                 id = Entities.PLAYER[status];
                 break;
             case Entities.ENEMY.name:
                 id = Entities.ENEMY[status];
                 break;
             case Entities.ROCKET.name:
                 id = Entities.ROCKET[status];
                 break;
             case Entities.EXIT.name:
                 return Entities.EXIT.id;
             case Entities.COIN.name:
                 return Entities.COIN.id;
             case Entities.WALL.name:
                 return Entities.WALL.id;
         }
        for (let i = 0; i < this.animations.length; i++) {
            let s = this.animations[i];
            if (s.id === id) {
                return s.animation[animIndex].tileid;
            }
        }
        console.log("NOT FOUND ANIM!");
        return null;
    },
};
